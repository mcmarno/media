<div class="header-top-area">
    <img width="2000" height="50" src="images/head.png">
</div>

<div class="mobile-menu-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="mobile-menu">
                            <nav id="dropdown">
                                <ul class="mobile-menu-nav">
                                    <li><a href="index.php">Home</a>
                                    </li>
                                    <li><a href="materiSiswa.php">Materi</a>
                                    </li>
                                    <li><a href="tugasSiswa.php">Tugas</a>
                                    </li>
                                    <li><a href="kamusSiswa.php">Kamus</a>
                                    </li>
                                    <li><a href="about.php">About me</a>
                                    </li>
                                    <li><a href="logout.php">Logout</a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Mobile Menu end -->
        <!-- Main Menu area start-->
        <div class="main-menu-area mg-tb-40">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <ul class="nav nav-tabs notika-menu-wrap menu-it-icon-pro">
                            <li><a href="index.php"><i class="notika-icon notika-house"></i> Home</a>
                            </li>
                            <li><a href="materiSiswa.php"><i class="notika-icon notika-file"></i> Materi</a>
                            </li>
                            <li><a href="tugasSiswa.php"><i class="notika-icon notika-edit"></i> Tugas</a>
                            </li>
                            <li><a href="kamusSiswa.php"><i class="notika-icon notika-form"></i> Kamus</a>
                            </li>
                            <li><a href="about.php"><i class="notika-icon notika-eye"></i> About me</a>
                            </li>
                            <li><a href="logout.php"><i class="notika-icon notika-close"></i> Logout</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>